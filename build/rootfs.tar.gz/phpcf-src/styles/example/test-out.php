<?php
// this file has namespace definition that needs to be formatted correctly:
namespace \Some\Weird\Thing;
