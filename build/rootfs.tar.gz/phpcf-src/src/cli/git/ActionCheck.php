<?php
/**
 * Check only changed lines
 * @author Alexander Krasheninnikov <a.krasheninnikov@corp.badoo.com>
 */
namespace Phpcf\Cli\Git;

class ActionCheck extends \Phpcf\Cli\ActionCheck
{
    protected $description = "check changes to be pushed";
}
