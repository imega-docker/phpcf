<?php

require_once __DIR__ . '/defines.php';
require_once __DIR__ . '/ClassLoader.php';

\Phpcf\ClassLoader::register();
