<?php
/**
 * Check only changed lines
 * @author Alexander Krasheninnikov <a.krasheninnikov@corp.badoo.com>
 */
namespace Phpcf\Cli\Git;

class ActionApply extends \Phpcf\Cli\ActionApply
{
    protected $description = "format changes to be pushed";
}
